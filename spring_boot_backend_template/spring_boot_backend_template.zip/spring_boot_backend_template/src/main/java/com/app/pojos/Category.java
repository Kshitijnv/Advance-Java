package com.app.pojos;

public enum Category {
	FASHION,ELECTRONICS
}
