package com.app.service;

import com.app.pojos.Player;

public interface PlayerService {
	String addPlayerToTeam(Player player,String abbreviation);
}
