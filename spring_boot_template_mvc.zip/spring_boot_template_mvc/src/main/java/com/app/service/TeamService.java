package com.app.service;

import java.util.List;

public interface TeamService {
		List<String> getTeamsAbbreviation();
}
